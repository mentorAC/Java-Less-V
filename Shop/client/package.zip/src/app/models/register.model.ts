export interface RegisterModel{
    username: string;
    email:string;
    phone: string;
    password: string;
}