export interface StatusModel {
  name: string;
  id: number;
}
