export interface PaymentTypeModel {
  id: number;
  name: string;
}
