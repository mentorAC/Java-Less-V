export interface UserModel {
  token: string;
  roles: string[];
}
