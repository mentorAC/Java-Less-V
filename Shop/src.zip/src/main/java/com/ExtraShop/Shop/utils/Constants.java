package com.ExtraShop.Shop.utils;

public class Constants {
    public static final String AUTH_HEADER = "Authorization";
}
